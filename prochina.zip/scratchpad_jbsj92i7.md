# Checklist for inspecting the site

- [x] Open index.html in the browser
- [x] Inspect Hero section
- [x] Inspect Notre Mission section
- [x] Inspect Pourquoi Nous Choisir section
- [x] Inspect Des solutions adaptées à chaque type de client section
- [x] Inspect Comment ça marche section
- [x] Inspect Obtenez votre cotation personnalisée (Form & Contact) section
- [x] Inspect Témoignages section
- [x] Inspect Footer section
- [x] Check responsiveness and design quality
- [x] Write final summary
